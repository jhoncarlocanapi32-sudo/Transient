const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    menuToggle.textContent = "☰";
  });
});

const stayButtons = document.querySelectorAll(".stay-option");
const selectedHours = document.getElementById("selectedHours");
const hourRadios = document.querySelectorAll('input[name="hours"]');

stayButtons.forEach((button) => {
  button.addEventListener("click", () => {
    stayButtons.forEach((item) => {
      item.classList.remove("selected");
      item.setAttribute("aria-pressed", "false");
    });
    button.classList.add("selected");
    button.setAttribute("aria-pressed", "true");
    const hours = button.dataset.hours;
    selectedHours.textContent = `${hours}-hour stay`;
    hourRadios.forEach((radio) => { radio.checked = radio.value === `${hours} hours`; });
  });
});

hourRadios.forEach((radio) => {
  radio.addEventListener("change", () => {
    const hours = radio.value.split(" ")[0];
    stayButtons.forEach((button) => {
      const selected = button.dataset.hours === hours;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    selectedHours.textContent = `${hours}-hour stay`;
  });
});

// Set the date field's minimum to today using the visitor's local date.
const dateInput = document.getElementById("checkIn");
const today = new Date();
const localToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
dateInput.min = localToday;
document.getElementById("year").textContent = today.getFullYear();

document.getElementById("bookingForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = form.get("guestName").trim();
  const date = form.get("checkIn");
  const guests = form.get("guests");
  const hours = form.get("hours");
  const message = form.get("message").trim();
  const inquiry = [
    "Hello Casa Sienna! I'd like to inquire about a stay.",
    "",
    `Name: ${name}`,
    `Preferred date: ${date}`,
    `Guests: ${guests}`,
    `Staying hours: ${hours}`,
    message ? `Additional notes: ${message}` : ""
  ].filter(Boolean).join("\n");

  const mailto = `mailto:?subject=${encodeURIComponent("Casa Sienna Stay Inquiry")}&body=${encodeURIComponent(inquiry)}`;
  window.location.href = mailto;
});
