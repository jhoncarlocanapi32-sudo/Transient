# Casa Sienna — Cozy Beachside Transient House

A responsive, one-page transient-house landing page built with plain HTML, CSS, and JavaScript. No framework, package manager, or build step required.

## Preview locally
1. Download or extract the ZIP.
2. Open `index.html` in a browser.

You can also use the **Live Server** extension in VS Code, but it is optional.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, and this `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`, then save.

GitHub Pages will publish the site at the URL shown in the Pages settings.

## Customize before publishing
- Replace **Casa Sienna** with your property name.
- Replace the sample Unsplash image URLs in `styles.css` with your own property photos if available.
- Add your actual address, contact number, social links, guest capacity, rates, and house rules.
- The booking form currently opens the visitor's default email app with a pre-filled inquiry. It does **not** submit to a booking system or confirm a reservation. Update the `mailto:` destination in `script.js` to your booking email address.
- The page uses Google Fonts and remote Unsplash photos, so those assets need an internet connection. The website itself has no build step or external JavaScript dependencies.

## Palette
- Sage green: `#34483b`
- Black/ink: `#201f1b`
- Warm brown: `#8b6548`
- Cream white: `#f7f3e9`
